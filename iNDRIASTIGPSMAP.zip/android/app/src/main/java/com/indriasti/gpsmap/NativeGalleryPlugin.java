package com.indriasti.gpsmap;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

@CapacitorPlugin(name = "NativeGallery")
public class NativeGalleryPlugin extends Plugin {

    @PluginMethod
    public void saveImageToGallery(PluginCall call) {
        String base64Data = call.getString("base64");
        String fileName = call.getString("fileName");

        if (base64Data == null || base64Data.isEmpty()) {
            call.reject("base64 data is required");
            return;
        }

        if (fileName == null || fileName.isEmpty()) {
            fileName = "GEO_" + System.currentTimeMillis() + ".jpg";
        }

        try {
            // Strip data:image/...;base64, prefix if present
            if (base64Data.contains(",")) {
                base64Data = base64Data.substring(base64Data.indexOf(",") + 1);
            }
            byte[] imageBytes = Base64.decode(base64Data, Base64.DEFAULT);

            Context context = getContext();
            ContentResolver resolver = context.getContentResolver();
            Uri imageUri = null;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/iNDRIASTIGPSMAP");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);

                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (imageUri == null) {
                    call.reject("Failed to create MediaStore entry");
                    return;
                }

                try (OutputStream os = resolver.openOutputStream(imageUri)) {
                    if (os != null) {
                        os.write(imageBytes);
                        os.flush();
                    } else {
                        call.reject("Failed to open output stream");
                        return;
                    }
                }

                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                resolver.update(imageUri, values, null, null);
            } else {
                File picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                File albumDir = new File(picturesDir, "iNDRIASTIGPSMAP");
                if (!albumDir.exists()) {
                    albumDir.mkdirs();
                }
                File imageFile = new File(albumDir, fileName);
                try (FileOutputStream fos = new FileOutputStream(imageFile)) {
                    fos.write(imageBytes);
                    fos.flush();
                }

                MediaScannerConnection.scanFile(context, new String[]{imageFile.getAbsolutePath()}, new String[]{"image/jpeg"}, null);
                imageUri = Uri.fromFile(imageFile);
            }

            JSObject ret = new JSObject();
            ret.put("success", true);
            ret.put("fileName", fileName);
            ret.put("bytesWritten", imageBytes.length);
            ret.put("uri", imageUri != null ? imageUri.toString() : "");
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Error saving image to gallery: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void openLocationSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            JSObject ret = new JSObject();
            ret.put("opened", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Error opening location settings: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void isLocationEnabled(PluginCall call) {
        try {
            LocationManager locationManager = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
            boolean isGpsEnabled = false;
            boolean isNetworkEnabled = false;

            if (locationManager != null) {
                try {
                    isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
                } catch (Exception ignored) {}
                try {
                    isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
                } catch (Exception ignored) {}
            }

            JSObject ret = new JSObject();
            ret.put("enabled", isGpsEnabled || isNetworkEnabled);
            ret.put("gps", isGpsEnabled);
            ret.put("network", isNetworkEnabled);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Error checking location status: " + e.getMessage(), e);
        }
    }
}
